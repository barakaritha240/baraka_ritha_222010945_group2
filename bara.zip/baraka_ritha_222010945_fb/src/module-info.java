/**
 * 
 */
/**
 * 
 */
module baraka_ritha_222010945_fb {
	requires mysql.connector.java;
	requires java.sql;
	requires java.desktop;
}